<?php
  $title = "CS143 DataBase Query System";
  $email = "jennie@jenniezheng.com";
?>