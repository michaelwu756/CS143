Division of Work:
Michael - wrote html part and php get request 
Jennie - set up vm and wrote eval 
